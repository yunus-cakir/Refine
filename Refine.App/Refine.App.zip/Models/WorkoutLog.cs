﻿using SQLite;

namespace Refine.App.Models;

public class WorkoutLog
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    public int WorkoutId { get; set; }
    public int ExerciseId { get; set; }

    public DateTime Date { get; set; }

    public int SetNumber { get; set; }
    public double? Weight { get; set; }
    public int? Reps { get; set; }

    public int? RIR { get; set; }
    public int FormRating { get; set; }

    public string? Note { get; set; }
}