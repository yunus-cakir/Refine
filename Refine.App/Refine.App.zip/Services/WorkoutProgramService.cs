﻿using Refine.App.Models;

namespace Refine.App.Services;

public class WorkoutProgramService
{
    private readonly List<WorkoutProgram> _programs = new();

    public WorkoutProgramService()
    {
        // Exercises
        var bench = new Exercise { Id = 1, Name = "Bench Press", Difficulty = "Intermediate", Equipment = "Barbell", MuscleGroup = "Chest" };
        var squat = new Exercise { Id = 2, Name = "Squat", Difficulty = "Intermediate", Equipment = "Barbell", MuscleGroup = "Legs" };

        // Workouts
        var workout1 = new Workout
        {
            Id = 1,
            Name = "Push Day",
            Description = "Beginner-friendly full body activation.",
            Order = 1,
            Items =
            {
                new WorkoutItem
                {
                    Id = 1,
                    ExerciseId = bench.Id,
                    Exercise = bench,
                    Sets = 4,
                    RepsRange = "8-12",
                    Order = 1
                }
            }
        };

        var workout2 = new Workout
        {
            Id = 2,
            Name = "Leg Day",
            Description = "Targeting quads, hamstrings and glutes.",
            Order = 2,
            Items =
            {
                new WorkoutItem
                {
                    Id = 2,
                    ExerciseId = squat.Id,
                    Exercise = squat,
                    Sets = 5,
                    RepsRange = "5-8",
                    Order = 1
                }
            }
        };

        // Program
        _programs.Add(new WorkoutProgram
        {
            Id = 1,
            Name = "Beginner Full Body",
            Level = "Beginner",
            Goal = "Muscle Gain",
            TargetMuscles = "Full Body",
            Environment = "Gym",
            Workouts = { workout1, workout2 }
        });
    }

    public Task<List<WorkoutProgram>> GetAllAsync()
        => Task.FromResult(_programs);

    public Task<WorkoutProgram?> GetByIdAsync(int id)
        => Task.FromResult(_programs.FirstOrDefault(p => p.Id == id));

    // 🔥 EKSİK OLAN METOT — BUNU EKLEYİNCE PROBLEM ÇÖZÜLÜYOR
    public Task<Workout?> GetWorkoutByIdAsync(int workoutId)
{
    foreach (var program in _programs)
    {
        var workout = program.Workouts.FirstOrDefault(w => w.Id == workoutId);
        if (workout != null)
            return Task.FromResult<Workout?>(workout);
    }

    return Task.FromResult<Workout?>(null);
}



}
