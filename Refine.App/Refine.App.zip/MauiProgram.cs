﻿using Microsoft.Extensions.Logging;
using Refine.App.Services; // Servislerin olduğu namespace

namespace Refine.App;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
            });

        // --- KRİTİK BÖLÜM: SERVİS KAYITLARI ---
        // Bu satırlar olmazsa uygulama "Inject" aşamasında çöker.

        builder.Services.AddMauiBlazorWebView();

#if DEBUG
        builder.Services.AddBlazorWebViewDeveloperTools();
        builder.Logging.AddDebug();
#endif

        // Veritabanı Servisi
        builder.Services.AddSingleton<LocalDbService>();

        // Kullanıcı Servisi (Home.razor'ın çökme sebebi muhtemelen buydu)
        builder.Services.AddSingleton<UserService>();

        // Eğer kullanıyorsan diğer servisler:
        // builder.Services.AddSingleton<ExerciseService>();
        // builder.Services.AddSingleton<WorkoutProgramService>();

        return builder.Build();
    }
}